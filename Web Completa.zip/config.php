<?
$dbh=mysql_connect("localhost","Usuario_db","clave_db");
mysql_select_db("base_de_Datos");
?>