/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
/*
CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';
	config.filebrowserUploadUrl = 'ckupload.php';
	config.language = 'es';
};*/

/**
 * @license Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	config.toolbarGroups = [
		{ name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },
		{ name: 'links',    },
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'paragraph'},
		{ name: 'insert', groups: [ 'image' ]},
		{ name: 'colors' }
	];
	config.removeButtons = 'Underline,Subscript,Superscript,Anchor,Table,HorizontalRule,SpecialChar,Flash,Smiley,PageBreak,Iframe,TextColor,BGColor';
	config.format_tags = 'p;h1;h2;h3;pre';
	config.autoParagraph = false;
	config.filebrowserUploadUrl = 'ckupload.php';
	config.language = 'es';
	config.enterMode = CKEDITOR.ENTER_BR;
	
};


