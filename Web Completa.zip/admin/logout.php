<?
session_start();
//session_destroy();
unset($_SESSION['adminuser']);
unset($_SESSION['adminid']);
?>
<script>location.href='index.php'</script>