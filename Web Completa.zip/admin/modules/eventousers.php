<?
if(isset($_SESSION['adminid']) && isset($_SESSION['adminuser'])){
	if(isset($_GET['evento']) && is_numeric($_GET['evento'])){
		
		$data_evento = mysql_query("SELECT * FROm eventos WHERE id_evento=".$_GET['evento']." LIMIT 1");
		if(mysql_num_rows($data_evento)>0){
		$row = mysql_fetch_array($data_evento);
	?>
	
	<h1>Usuarios que asistir&aacute;n al evento</h1>
	
        
			<div class="user-form form_extend2">
            	<h4>Evento: <?=$row['nombre']?></h4>
                <?
                $ver_inscritos = mysql_query("SELECT usuarios.id_user ,usuarios.nombre  FROM eventos_usuarios,usuarios WHERE eventos_usuarios.id_user=usuarios.id_user AND eventos_usuarios.id_evento = ".$_GET['evento']."");
				if(mysql_num_rows($ver_inscritos)>0){
				?>
				<div class="form-group">
					<ul>
                    	<? while($user = mysql_fetch_array($ver_inscritos)){ ?>
                    	<li><a href="../index.php?id=profile&user=<?=$user['id_user']?>" target="_blank"><?=$user['nombre']?></a></li>
                        <? } ?>
                    </ul>
				</div>
                <?
				} else {
					echo "<br><br>No hay usuarios inscritos a este evento";
				}
				?>
            </div>
            <div class="user-form form_extend">
                <div class="form-group" id="buttons"><br><input type="button" onclick="history.back()" value="Volver"></div>
			</div>	
            <input type="hidden" name="id_evento" value="<?=$row['id_evento']?>" />   	 	 
        </form>
        <br /><br />
<? 
		} else {
			echo "Este evento no existe.";	
		}
		
	} else {
		echo "ID Error";	
	}
} else {
	
}
?>
